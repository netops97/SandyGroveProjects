from django.apps import AppConfig


class PagesConfig(AppConfig):
    name = 'pages'
