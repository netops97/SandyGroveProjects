Placeholder only.

Folder is only to show you where the virtual enviroment should be in your project structure.

You need to create your own virtual environment.